# multi_gateway.py
import time
import requests
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from gptcache.adapter.api import get as cache_get, put as cache_put
from cache_switch import switch_cache
from policy import NoopPolicy, CostAwarePolicy, BasePolicy

OLLAMA_URL = "http://localhost:11434/api/generate"

def ollama_generate(model: str, prompt: str, timeout_s=300) -> str:
    r = requests.post(OLLAMA_URL, json={"model": model, "prompt": prompt, "stream": False}, timeout=timeout_s)
    r.raise_for_status()
    return r.json().get("response", "")

@dataclass
class PolicyState:
    name: str
    run_tag: str
    policy_impl: BasePolicy
    hits: int = 0
    misses: int = 0
    latencies_ms: List[float] = field(default_factory=list)
    events: List[Dict[str, Any]] = field(default_factory=list)

class MultiCacheGateway:
    """
    Compare policies fairly: per prompt, measure lookup for each policy; if any policy misses,
    call model ONCE; attribute model latency only to the policies that missed; backfill misses.
    """
    def __init__(self, model_name: str, policies: List[PolicyState],
                 similarity_max_distance: float = 0.6):
        self.model_name = model_name
        self.policies = policies
        self.similarity_max_distance = similarity_max_distance

    def ask(self, prompt: str) -> Dict[str, Any]:
        lookups = []  # per policy: {pol, hit, lookup_ms, ans}
        any_miss = False

        # 1) Lookups for all policies; track hits/misses & lookup latencies
        for pol in self.policies:
            switch_cache(pol.run_tag, self.similarity_max_distance)
            t0 = time.perf_counter()
            ans = cache_get(prompt)
            lookup_ms = (time.perf_counter() - t0) * 1000.0
            hit = ans is not None
            if hit:
                pol.hits += 1
                pol.policy_impl.on_hit(prompt, meta={})
            else:
                pol.misses += 1
                any_miss = True
            lookups.append(dict(pol=pol, hit=hit, lookup_ms=lookup_ms, ans=ans))

        # 2) If any policy missed, call model ONCE
        answer: Optional[str] = None
        model_ms: float = 0.0
        if any_miss:
            t0 = time.perf_counter()
            answer = ollama_generate(self.model_name, prompt)
            model_ms = (time.perf_counter() - t0) * 1000.0

        # 3) Attribute per-policy latency, mutate only miss policies
        for rec in lookups:
            pol: PolicyState = rec["pol"]
            if rec["hit"]:
                pol.latencies_ms.append(rec["lookup_ms"])
                pol.events.append({
                    "prompt": prompt,
                    "ts": time.time(),
                    "lookup_ms": rec["lookup_ms"],
                    "model_ms": 0.0,
                    "e2e_ms": rec["lookup_ms"],
                    "hit": 1,
                    "path": "lookup_hit",
                })
            else:
                # write the model answer into this policy's cache, attribute model latency
                switch_cache(pol.run_tag, self.similarity_max_distance)
                cache_put(prompt, answer or "")
                pol.policy_impl.on_put(
                    prompt, answer or "", meta={"size_bytes": len((answer or "").encode("utf-8")),
                                                "saved_latency_ms": model_ms}
                )
                pol.policy_impl.maybe_evict()
                end_to_end = rec["lookup_ms"] + model_ms
                pol.latencies_ms.append(end_to_end)
                pol.events.append({
                    "prompt": prompt,
                    "ts": time.time(),
                    "lookup_ms": rec["lookup_ms"],
                    "model_ms": model_ms,
                    "e2e_ms": end_to_end,
                    "hit": 0,
                    "path": "lookup_miss+model",
                })

        # 4) Return an answer (prefer any hit answer, else the model answer)
        ret = next((r["ans"] for r in lookups if r["hit"]), None)
        if ret is None:
            ret = answer or ""
        return {"answer": ret}
