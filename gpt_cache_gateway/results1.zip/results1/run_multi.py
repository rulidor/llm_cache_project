# run_multi.py
import csv
import json
import time
import os
from typing import List
from cache_setup import build_cache
from multi_gateway import MultiCacheGateway, PolicyState
from policy import NoopPolicy, CostAwarePolicy
from requests.exceptions import ReadTimeout


def clean_files(run_tag):
    files_to_remove = ["faiss.index", f"results_{run_tag}.csv"]
    for fname in files_to_remove:
        if os.path.exists(fname):
            os.remove(fname)
            print(f"Removed {fname}")

def percentile(xs: List[float], p: float) -> float:
    if not xs:
        return 0.0
    xs = sorted(xs)
    k = (len(xs) - 1) * p / 100.0
    f, c = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[f] if f == c else xs[f] + (xs[c] - xs[f]) * (k - f)

def build_prompts(n=100) -> List[str]:
    with open("prompt_stream.json", "r", encoding="utf-8") as f:
        prompts_db = json.load(f)
    prompts: List[str] = []
    for prompt in prompts_db:
        if len(prompts) == n:
            break
        prompts.append(prompt["prompt"])
    return prompts

def virtual_throughput_req_per_s(latencies_ms):
    """Policy-virtual throughput: n / (sum(e2e_ms)/1000)."""
    if not latencies_ms:
        return 0.0
    total_s = sum(latencies_ms) / 1000.0
    n = len(latencies_ms)
    return n / total_s if total_s > 0 else 0.0

def write_csv(name: str, pol: PolicyState):
    with open(f"results_{name}.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        # richer columns
        w.writerow(["ts","prompt","hit","lookup_ms","model_ms","e2e_ms","path"])
        for e in pol.events:
            w.writerow([
                f'{e.get("ts",0):.6f}',
                e["prompt"],
                e["hit"],
                f'{e.get("lookup_ms",0.0):.3f}',
                f'{e.get("model_ms",0.0):.3f}',
                f'{e.get("e2e_ms",0.0):.3f}',
                e.get("path",""),
            ])
        w.writerow([])
        w.writerow(["hits", pol.hits])
        w.writerow(["misses", pol.misses])
        w.writerow(["evictions", getattr(pol.policy_impl, "evictions", 0)])

if __name__ == "__main__":
    for tag in ["baseline", "costaware"]:
        clean_files(tag)

    # Clean caches once per policy
    build_cache(run_tag="baseline", similarity_max_distance=0.6, reset_files=True)
    build_cache(run_tag="costaware-32k", similarity_max_distance=0.6, reset_files=True)

    baseline = PolicyState("baseline", "baseline", NoopPolicy())
    costaware = PolicyState("costaware", "costaware-32k", CostAwarePolicy(byte_budget=32*1024))

    gw = MultiCacheGateway(model_name="phi3:mini",
                           policies=[baseline, costaware],
                           similarity_max_distance=0.6)

    prompts = build_prompts(475)
    print("Prompts were successfully built")

    # Wall-clock timing for true throughput
    t0 = time.perf_counter()
    for i, p in enumerate(prompts):
        print(f"Processing prompt number {i}")
        try:
            gw.ask(p)
        except ReadTimeout:
            print("[WARN] Ollama timed out on")
            continue
        except Exception as e:
            print(f"[ERROR] Ollama request failed: {e}")
            continue
    total_s = time.perf_counter() - t0
    overall_throughput = len(prompts) / total_s if total_s > 0 else 0.0

    print(f"\nOverall: requests={len(prompts)} duration={total_s:.2f}s "
          f"throughput={overall_throughput:.2f} req/s")

    # Per-policy summaries (now include virtual throughput)
    for pol in (baseline, costaware):
        n = len(pol.latencies_ms)
        p50 = percentile(pol.latencies_ms, 50)
        p95 = percentile(pol.latencies_ms, 95)
        p99 = percentile(pol.latencies_ms, 99)
        hit_rate = (pol.hits / n) if n else 0.0
        v_tput = virtual_throughput_req_per_s(pol.latencies_ms)

        print(f"{pol.name}: n={n} hits={pol.hits} misses={pol.misses} "
              f"hit_rate={hit_rate:.2%} p50={p50:.1f}ms p95={p95:.1f}ms p99={p99:.1f}ms "
              f"evictions={getattr(pol.policy_impl,'evictions',0)} "
              f"virtual_throughput={v_tput:.2f} req/s")

        write_csv(pol.name, pol)

    print("\nCSVs -> results_baseline.csv, results_costaware.csv")
