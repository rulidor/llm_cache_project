# policy.py
import heapq
import time
from typing import Dict, Any
from gptcache import cache as GLOBAL_CACHE  # singleton; points to whichever run_tag is active

class BasePolicy:
    """Hook interface for external policies (optional)."""
    evictions: int = 0
    def on_put(self, key: str, answer: str, meta: Dict[str, Any]): ...
    def on_hit(self, key: str, meta: Dict[str, Any]): ...
    def maybe_evict(self): ...

class NoopPolicy(BasePolicy):
    """Baseline: rely on GPTCache's own limits only."""
    def __init__(self):
        self.evictions = 0
    def on_put(self, key, answer, meta): pass
    def on_hit(self, key, meta): pass
    def maybe_evict(self): pass

class CostAwarePolicy(BasePolicy):
    """
    Evict entries with the lowest (benefit_per_byte) until under byte_budget.
    benefit ~ saved_latency_ms * (1 + 0.25*hits) * recency_boost
    Tracks items by prompt key; uses GLOBAL_CACHE.data_manager.delete(key) if available.
    """
    def __init__(self, byte_budget: int = 50_000):
        self.byte_budget = byte_budget
        self.bytes_used = 0
        self.meta: Dict[str, Dict[str, Any]] = {}
        self.evictions = 0

    def _score(self, m: Dict[str, Any]) -> float:
        benefit = m.get("saved_latency_ms", 0.0) * (1.0 + 0.25 * m.get("hits", 0))
        recency = 1.0 / (1.0 + (time.time() - m.get("last_access", time.time())) / 300.0)
        return (benefit * recency) / max(1, m.get("size_bytes", 1))

    def on_put(self, key: str, answer: str, meta: Dict[str, Any]):
        sz = meta.get("size_bytes", len(answer.encode("utf-8")))
        self.meta[key] = dict(
            size_bytes=sz,
            hits=0,
            last_access=time.time(),
            saved_latency_ms=meta.get("saved_latency_ms", 0.0),
        )
        self.bytes_used += sz

    def on_hit(self, key: str, meta: Dict[str, Any]):
        m = self.meta.get(key)
        if m:
            m["hits"] += 1
            m["last_access"] = time.time()
            if "saved_latency_ms" in meta:
                m["saved_latency_ms"] = max(m["saved_latency_ms"], meta["saved_latency_ms"])

    def maybe_evict(self):
        if self.bytes_used <= self.byte_budget:
            return
        heap = [(self._score(m), k) for k, m in self.meta.items()]
        heapq.heapify(heap)

        dm = getattr(GLOBAL_CACHE, "data_manager", None)
        while self.bytes_used > self.byte_budget and heap:
            _, victim = heapq.heappop(heap)
            try:
                if dm and hasattr(dm, "delete"):
                    dm.delete(victim)  # delete by key (prompt) if your fork supports it
            except Exception:
                pass
            sz = self.meta.get(victim, {}).get("size_bytes", 0)
            self.bytes_used -= sz
            self.meta.pop(victim, None)
            self.evictions += 1
