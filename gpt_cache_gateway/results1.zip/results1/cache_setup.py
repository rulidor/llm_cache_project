# cache_setup.py
import os
from gptcache import cache as GLOBAL_CACHE
from gptcache.manager import get_data_manager, CacheBase, VectorBase
from gptcache.similarity_evaluation.distance import SearchDistanceEvaluation
from gptcache.processor.pre import get_prompt
from sentence_transformers import SentenceTransformer as ST

# MiniLM-L6-v2 → 384 dims
_ST = ST("sentence-transformers/all-MiniLM-L6-v2")

def to_embeddings(x, **kwargs):
    """Return 1-D list for str, list of 1-D for list; ignore extra kwargs."""
    if isinstance(x, str):
        v = _ST.encode([x], convert_to_numpy=True, normalize_embeddings=True)
        return v[0].tolist()
    elif isinstance(x, (list, tuple)):
        return _ST.encode(list(x), convert_to_numpy=True, normalize_embeddings=True).tolist()
    # fallback
    v = _ST.encode([str(x)], convert_to_numpy=True, normalize_embeddings=True)
    return v[0].tolist()

def build_cache(
    run_tag: str,
    similarity_max_distance: float = 0.6,
    dim: int = 384,
    reset_files: bool = True,
):
    """
    Initialize the GLOBAL GPTCache singleton with per-run file paths.
    Use reset_files=True at the start of a run to guarantee a clean cache.
    """
    index_path = f"faiss_{run_tag}.index"
    sqlite_path = f"cache_{run_tag}.db"

    if reset_files:
        for p in (index_path, sqlite_path):
            try:
                os.remove(p)
            except FileNotFoundError:
                pass

    cache_base = CacheBase("sqlite", url=f"sqlite:///{sqlite_path}")
    # Older GPTCache needs index_file_path + top_k in VectorBase
    vector_base = VectorBase("faiss", dimension=dim, index_file_path=index_path, top_k=1)

    dm = get_data_manager(
        cache_base=cache_base,
        vector_base=vector_base,
        max_size=2000,   # internal LRU item cap
        clean_size=200,
    )

    # Your fork: evaluator uses a distance threshold (lower = stricter)
    sim = SearchDistanceEvaluation(max_distance=similarity_max_distance, positive=False)

    GLOBAL_CACHE.init(
        pre_embedding_func=get_prompt,
        embedding_func=to_embeddings,
        data_manager=dm,
        similarity_evaluation=sim,
    )
    return GLOBAL_CACHE, {"index_path": index_path, "sqlite_path": sqlite_path}
