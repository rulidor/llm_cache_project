# cache_switch.py
from cache_setup import build_cache

def switch_cache(run_tag: str, similarity_max_distance: float = 0.6):
    """
    Re-initialize GPTCache's global singleton to use this policy's files.
    DO NOT delete files while switching during a run.
    """
    cache, _ = build_cache(
        run_tag=run_tag,
        similarity_max_distance=similarity_max_distance,
        reset_files=False,
    )
    return cache
